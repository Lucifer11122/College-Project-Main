const about = () => {
    return (
      <div>
        <h1>Chat Page</h1>
      </div>
    );
  };
  
  export default about;
  