const Courses = () => {
    return (
      <div>
        <h1>Chat Page</h1>
      </div>
    );
  };
  
  export default Courses;
  