import React from 'react'

function administration() {
  return (
    <div>administration</div>
  )
}

export default administration