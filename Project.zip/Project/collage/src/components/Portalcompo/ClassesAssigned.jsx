
const ClassesAssigned = () => {
  return (
    <div>
      <h1>
      ClassesAssigned
      </h1>
    </div>
  )
}

export default ClassesAssigned
