
const Milestones = () => {
  return (
    <div>
      <h1>Milestones</h1>
    </div>
  )
}

export default Milestones
