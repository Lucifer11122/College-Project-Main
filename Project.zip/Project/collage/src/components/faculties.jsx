import React from 'react'

function faculties() {
  return (
    <div>faculties</div>
  )
}

export default faculties